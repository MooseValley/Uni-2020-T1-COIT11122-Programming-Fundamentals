/*
Author: Mike OMalley
Source: BarChart.java

Java - Basic Console App - Week 04
13. The Huntington High School basketball team has five players named
Moose, Frankie, Bella, Teenie, and Sam. Accept the number of points scored
by each player in a game and create a bar chart that illustrates the
points scored.
Save the file as BarChart.java.

------------------------------------------------------------
Enter points scored by Moose:    3
Enter points scored by Frankie:  12
Enter points scored by Bella:    8
Enter points scored by Teenie:   6
Enter points scored by Sam:      15

Points Bar Graph:
Moose    ***
Frankie  ************
Bella    ********
Teenie   ******
Sam      ***************
------------------------------------------------------------
*/
public class BarChart
{
}