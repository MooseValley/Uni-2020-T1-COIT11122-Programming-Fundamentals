/*
Author: Mike OMalley
Source: Population.java

Java - Basic Console App - Week 04
12. Assume that the population of Mexico is 121 million and that the population
increases 1.01 percent annually. Assume that the population of the United States is
315 million and that the population is reduced 0.15 percent annually. Write an
application that displays the populations for the two countries every year until the
population of Mexico exceeds that of the United States, and display the number of
years it took. Save the file as Population.java.
*/

public class Population
{
}
