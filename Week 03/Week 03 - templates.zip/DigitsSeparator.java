/*
 Author: Mike O
 File:   DigitsSeparator.java
 Desc:   Week 03: Tutorial Question 5.

Question Five
Write an application which inputs one number consisting of five digits
from the user, separates the number into its individual digits and
prints the digits separated from one another by three spaces each.
For example, if the user types in the number 42339, the program
should print "4 2 3 3 9.� Assume that the user enters the correct
number of digits.
*/
